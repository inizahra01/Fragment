package com.example.fragment

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.fragment.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Menampilkan Fragment A sebagai tampilan awal
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.frame_container, FragmentA())
                .commit()
        }

        // Setup click listeners untuk tombol-tombol
        binding.btnFragmentA.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.frame_container, FragmentA())
                .commit()
        }

        binding.btnFragmentB.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.frame_container, FragmentB())
                .addToBackStack(null)
                .commit()
        }
    }
}